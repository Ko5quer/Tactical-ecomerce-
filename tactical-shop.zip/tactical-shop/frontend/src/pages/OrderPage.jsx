import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import RequireLogin from "../components/RequireLogin";
import { api, errorMessage, formatPrice, mediaUrl } from "../components/api";

function OrderDetails() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api(`/api/orders/${id}/`)
      .then(setOrder)
      .catch((err) => setError(err.status === 404 ? "Order not found." : errorMessage(err)));
  }, [id]);

  if (error) return <div className="notice"><p>{error}</p></div>;
  if (!order) return <p className="muted">Loading…</p>;

  return (
    <div className="cart">
      <ul className="cart__list">
        {order.order_items.map((item) => {
          const img = mediaUrl(item.product.image);
          return (
            <li key={item.id} className="cart__row cart__row--order">
              <div className="cart__img">{img ? <img src={img} alt="" /> : <span>—</span>}</div>
              <div className="cart__info">
                <h3>{item.product.product_name}</h3>
                <p className="muted">
                  {item.quantity} × {formatPrice(item.price)}
                </p>
              </div>
              <div className="cart__line">{formatPrice(Number(item.price) * item.quantity)}</div>
            </li>
          );
        })}
      </ul>

      <aside className="summary">
        <h2>Order #{order.id}</h2>
        <dl>
          <div><dt>Status</dt><dd className="cap">{order.status}</dd></div>
          <div><dt>Placed</dt><dd>{new Date(order.created_at).toLocaleDateString()}</dd></div>
          <div><dt>Payment</dt><dd>Cash on delivery</dd></div>
        </dl>
        <div className="summary__total">
          <span>Total</span>
          <strong>{formatPrice(order.total)}</strong>
        </div>
        <Link to="/categories" className="btn btn--block">Keep shopping</Link>
      </aside>
    </div>
  );
}

export default function OrderPage() {
  return (
    <main className="page">
      <header className="page__head">
        <p className="page__eyebrow">Thank you</p>
        <h1 className="page__title">Order placed</h1>
      </header>
      <RequireLogin message="Log in to view this order.">
        <OrderDetails />
      </RequireLogin>
    </main>
  );
}
