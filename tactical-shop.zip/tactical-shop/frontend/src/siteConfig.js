/* =====================================================================
   SITE CONFIG — the one file to edit for everyday changes.
   Nav links, hero text and section headings all live here.
   ===================================================================== */

export const SITE = {
  name: "Airsoft Guild", // used for the logo's alt text
};

/* ---------------------------------------------------------------------
   TOP MENU
   Each entry becomes a link in the banner (and in the mobile menu).
   Order here = order on screen.

   To add a page:
     1. create the page file in src/pages/        (e.g. AboutPage.jsx)
     2. add a <Route> for it in src/App.jsx
     3. add / uncomment a line below

   Fields:
     label     text shown in the menu
     href      where it goes ("/about", or a full https:// link)
     external  (optional) true = open in a new tab, for other websites
   --------------------------------------------------------------------- */
export const NAV_LINKS = [
  { label: "Home", href: "/" },
  { label: "Categories", href: "/categories" },

  // Pages already built and routed — just uncomment to show them:
  // { label: "About", href: "/about" },
  // { label: "Book Events", href: "/events" },

  // Link to another website:
  // { label: "Instagram", href: "https://instagram.com/yourpage", external: true },
];

/* ---------------------------------------------------------------------
   HOME BANNER TEXT
   --------------------------------------------------------------------- */
export const HERO = {
  eyebrow: "Tactical / Outdoor / Firearms",
  titleLead: "Gear for a",
  titleAccent: "Higher purpose.",
  text: "Quality tactical clothing, outdoor gear and firearms accessories for those who never settle.",
  buttonLabel: "Shop now",
  buttonHref: "/categories",
};

/* ---------------------------------------------------------------------
   "FEATURED PRODUCTS" SECTION ON THE HOME PAGE
   limit = how many random products to show
   --------------------------------------------------------------------- */
export const FEATURED = {
  limit: 8,
  eyebrow: "Picked for you",
  title: "Featured gear",
  subtitle: "A random mix from across the shop. Refresh for a new selection.",
};
